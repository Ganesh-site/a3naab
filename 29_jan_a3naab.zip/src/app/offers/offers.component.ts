import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { OffersService } from './offers.service';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
declare var $:any;

@Component({
  selector: 'app-offers',
  templateUrl: './offers.component.html',
  styleUrls: ['./offers.component.css']
})
export class OffersComponent implements OnInit {

  addOffers: FormGroup;
  datePickerConfig:Partial<BsDatepickerConfig>;

  bsValue: Date = new Date();
  bsValue1: Date = new Date();
   status: any = true;

  list_offers: any = [];
  constructor(
    private formBuilder:FormBuilder,
    private offersservice:OffersService
    ) { }

  ngOnInit(): void {
    this.getofferslist("active");
    this.addOffers   = this.formBuilder.group({
      start_date: [this.bsValue,  [ Validators.required, Validators.pattern(/^\S+(?: \S+)*$/)]],
      end_date: [this.bsValue1,  [ Validators.required, Validators.pattern(/^\S+(?: \S+)*$/)]],
      trust_usr:['',  [ Validators.required, Validators.pattern(/^\S+(?: \S+)*$/)]],
      offer_title: ['',  [ Validators.required, Validators.pattern(/^\S+(?: \S+)*$/)]],
      offer_desc: ['',  [ Validators.required, Validators.pattern(/^\S+(?: \S+)*$/)]],
      coupon_code: ['',  [ Validators.required, Validators.pattern(/^\S+(?: \S+)*$/)]],
      discount: ['',  [ Validators.required, Validators.pattern(/^\S+(?: \S+)*$/)]],
      min_ord_value: ['',  [ Validators.required, Validators.pattern(/^\S+(?: \S+)*$/)]],
      max_count: ['',  [ Validators.required, Validators.pattern(/^\S+(?: \S+)*$/)]],
  });
  

}
onSubmit(){
// console.log("res",this.addOffers.value)
var params = {}
if(!this.addOffers.valid){
  this.offersservice.showToast('Fill all mandatory fields !!', 'Error', 'errorToastr')
}


// this.offersservice.addofferservice(params).subscribe(
//   (response: any) => {
//     if (response.body.error == 'false') {
//       // Success
//       this.offersservice.showToast(response.body.message, 'Success', 'successToastr')
//       // $('#add_driv_btn').modal('hide');
//       this.ngOnInit();
//       // this.router.navigateByUrl('/dashboard');
//     } else {
//       // Query Error
//       this.offersservice.showToast(response.body.message, 'Error', 'errorToastr')
//     }
//   },
//   (error) => {
//     this.offersservice.showToast('Server Error !!', 'Oops', 'errorToastr')
//     console.log('Error', error)
//   }
// )
}

editoffers(offers){
  $('#add_offer_btn').modal('show');
 console.log("Edit offer",offers)
}
onchange(){
  // this.status = !stat;
  console.log(this.status);
}


getofferslist(status){
  let off_li = {
    url: "admin/getOfferList",
    status: status
  }

  this.offersservice.getoffservice(off_li).subscribe((result:any)=>{
    // console.log('offers response', result.body);
    let resu = result.body;
    if(resu.error == "false")
    {
         this.list_offers = resu.data.Offers;
    }else{
      this.offersservice.showToast(resu.message, 'Error', 'errorToastr')
    }
  },(error)=>{
     console.error(error);
  });
}

}



