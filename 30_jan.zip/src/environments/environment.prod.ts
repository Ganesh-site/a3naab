export const environment = {
  production: true,
  // baseUrl: 'http://15.184.21.76:3000/',
  baseUrl: 'http://15.185.182.194/dev/'
};
