import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-products-stats',
  templateUrl: './products-stats.component.html',
  styleUrls: ['./products-stats.component.css']
})
export class ProductsStatsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
